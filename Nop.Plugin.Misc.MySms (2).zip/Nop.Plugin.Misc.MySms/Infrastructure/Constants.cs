﻿namespace Nop.Plugin.Misc.Sms.Infrastructure
{
    public static class Constants
    {
        public enum HttpMethod
        {
            Get,
            Post
        }
    }
}
