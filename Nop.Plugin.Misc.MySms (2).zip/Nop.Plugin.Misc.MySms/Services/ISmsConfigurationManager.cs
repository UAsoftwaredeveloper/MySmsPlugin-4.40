﻿using Nop.Plugin.Misc.Sms.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Nop.Plugin.Misc.Sms.Services
{
    public interface ISmsConfigurationManager
    {
       
        decimal GetSmswallet();
    }
}